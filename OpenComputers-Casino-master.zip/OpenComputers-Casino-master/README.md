# OpenComputers Casino


### Requirements
* OpenComputers
* Computronics or non-private chest
* Applied Energistics 2


### Quick start
1. Launch OpenOS
2. type 'edit casino'
3. insert install.lua content
4. Ctrl + S then Ctrl + W
5. type 'casino'
6. edit settings as you need
7. Ctrl + S then Ctrl + W
8. type '1'